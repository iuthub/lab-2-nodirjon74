# Lab 2

Clone this repository to your local computer and make your modifications as given in `lab2.pdf` file. Make sure that you finish everything given in `lab2.pdf` file. You can push your folder back to this repository after creating your web page.